// models/level_model.dart
class Level {
  int level;
  int experiencePoints;
  int experienceRequired;

  Level({required this.level, required this.experiencePoints, required this.experienceRequired});
}
