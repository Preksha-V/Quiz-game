// models/leaderboard_model.dart
class LeaderboardEntry {
  String username;
  int totalScore;

  LeaderboardEntry({required this.username, required this.totalScore});
}
